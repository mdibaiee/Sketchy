Brush
=====

An image manipulation tool written in Javascript
